import 'package:flutter/material.dart';
import 'package:quiz3/home.dart';
void main() {
  runApp(
      MaterialApp(
        title:'Interactive Screen',
        home: Home(),
        debugShowCheckedModeBanner: false,
      )
  );
}
